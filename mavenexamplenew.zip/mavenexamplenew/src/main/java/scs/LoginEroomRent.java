package scs;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginEroomRent {
	WebDriver driver;
	By username = By.name("txtEmail");
	By password = By.name("txtPassword");
	By btn = By.name("btnsubmit");
	
	public LoginEroomRent(WebDriver driver) {
		this.driver=driver;
	}
	public void enterUsername(String arg1) {
		driver.findElement(username).sendKeys(arg1);
		}
	public void enterPassword(String arg1) {
		driver.findElement(password).sendKeys(arg1);
		}
	public void clickOnGetStarted() {
		driver.findElement(btn).click();
		}
}
