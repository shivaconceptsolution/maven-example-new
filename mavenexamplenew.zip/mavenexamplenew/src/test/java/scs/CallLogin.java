package scs;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class CallLogin {
	WebDriver driver;
	LoginEroomRent obj;
	@BeforeTest
	public void setup() {
	System.setProperty("webdriver.chrome.driver", "C:\\chromedriver.exe");
	driver = new ChromeDriver();
	driver.get("https://www.eroomrent.in/ownerlogin.php");
	}
  @Test
  public void f() {
	  obj= new LoginEroomRent(driver);
	  obj.enterUsername("owner@gmail.com");
	  obj.enterPassword("12345678");
	  obj.clickOnGetStarted();
  }
  
}
